import {useEffect,useMemo,useState} from 'react';
import {Play,Pause,RotateCcw,ChevronLeft,ChevronRight,Maximize2,VolumeX} from 'lucide-react';

type Scene={date:string;name:string;tag:string;headline:string;thought:string;detail:string;route:[number,number][];troops:[number,number][];enemy:[number,number][]};
const scenes:Scene[]=[
{date:'1935年1月 · 黔北',name:'战略危局',tag:'序章 / THE CRISIS',headline:'兵力悬殊，如何突破围追堵截？',thought:'真正的问题，不是向哪里进攻，而是如何保存实力、争取主动。',detail:'遵义会议后，中央红军仍面临敌军围追堵截。',route:[[695,350],[590,315]],troops:[[590,315],[620,342],[555,365]],enemy:[[350,160],[810,205],[760,460],[410,500]]},
{date:'1935年1月29日',name:'一渡赤水',tag:'第一渡 / CHANGE THE PLAN',headline:'形势改变，计划也必须改变。',thought:'从实际出发：不能为了坚持原定方向而陷入不利局面。',detail:'土城战斗后，红军从土城、元厚一带西渡赤水，向川南机动。',route:[[590,315],[515,270],[440,240]],troops:[[440,240],[465,260],[410,265]],enemy:[[720,325],[800,205],[650,475],[330,425]]},
{date:'1935年2月18—21日',name:'二渡赤水',tag:'第二渡 / STRIKE THE WEAK POINT',headline:'不与强敌硬碰，回师黔北。',thought:'避实击虚：敌军的部署变化，也可能成为自己的战机。',detail:'红军从太平渡、二郎滩一带东渡，随后取得娄山关、遵义等战斗胜利。',route:[[440,240],[525,290],[660,350]],troops:[[660,350],[635,380],[690,390]],enemy:[[370,240],[820,195],[810,480],[430,475]]},
{date:'1935年3月16—17日',name:'三渡赤水',tag:'第三渡 / DRAW THE ENEMY',headline:'让敌人追着自己的行动改变部署。',thought:'高明的机动，不只是自己转移，更在于影响对手的判断。',detail:'红军由茅台及附近地区西渡赤水，向川南行动，牵动敌军。',route:[[660,350],[540,300],[460,250]],troops:[[460,250],[435,285],[485,285]],enemy:[[570,200],[735,325],[665,480],[365,445]]},
{date:'1935年3月21—22日',name:'四渡赤水',tag:'第四渡 / REGAIN INITIATIVE',headline:'突然东返，把主动权握回手中。',thought:'改变方向，不等于放弃目标。机动的目的，是创造新的选择。',detail:'红军由太平渡、二郎滩等地再渡赤水，随后南渡乌江，向云南机动。',route:[[460,250],[560,315],[690,355],[740,490]],troops:[[690,355],[665,380],[710,395]],enemy:[[385,230],[470,410],[825,270],[860,490]]},
{date:'1935年5月 · 战略回望',name:'全局复盘',tag:'终章 / THE ART OF STRATEGY',headline:'兵无常势，水无常形。',thought:'在变化中识别机会，在劣势中创造主动。',detail:'四渡赤水之后，红军继续机动，最终渡过金沙江，摆脱优势敌军的围追堵截。',route:[[590,315],[440,240],[660,350],[460,250],[690,355],[740,490],[560,565]],troops:[[560,565],[585,540],[535,535]],enemy:[[380,225],[820,210],[820,450],[375,480]]}
];
const DURATIONS=[19,33,40,37,39,32];
const total=DURATIONS.reduce((a,b)=>a+b,0);
const path=(pts:[number,number][])=>pts.map((p,i)=>(i?'L':'M')+p.join(' ')).join(' ');
function indexFor(t:number){let v=t;for(let i=0;i<DURATIONS.length;i++){if(v<DURATIONS[i])return {i,local:v/DURATIONS[i]};v-=DURATIONS[i]}return {i:5,local:1}}
function clock(n:number){return `${Math.floor(n/60).toString().padStart(2,'0')}:${Math.floor(n%60).toString().padStart(2,'0')}`}
function Map({scene,progress}:{scene:Scene,progress:number}){
const d=path(scene.route);
return <svg className="terrain" viewBox="0 0 1100 630" preserveAspectRatio="xMidYMid slice" aria-label="川滇黔战役动态示意地图">
<defs><radialGradient id="land"><stop stopColor="#435247"/><stop offset="1" stopColor="#172b2b"/></radialGradient><pattern id="gr" width="42" height="42" patternUnits="userSpaceOnUse"><path d="M42 0H0V42" stroke="#e5d9ad" strokeOpacity=".07" fill="none"/></pattern><filter id="glow"><feGaussianBlur stdDeviation="4"/></filter></defs>
<rect width="1100" height="630" fill="url(#land)"/><rect width="1100" height="630" fill="url(#gr)"/>
<g stroke="#b8bc9b" strokeWidth="1.4" fill="none" opacity=".12">{Array.from({length:15},(_,i)=><path key={i} d={`M-50 ${i*49-90} Q 230 ${i*48-150} 460 ${i*48-30} T 1150 ${i*46-70}`}/>)}</g>
<path d="M350 -50 Q 380 75 465 140 T 515 270 T 585 360 T 700 470 T 795 670" stroke="#4c8ca3" strokeWidth="18" fill="none" opacity=".7"/>
<path d="M350 -50 Q 380 75 465 140 T 515 270 T 585 360 T 700 470 T 795 670" stroke="#b5cbd0" strokeWidth="2" strokeDasharray="6 13" fill="none" opacity=".65"/>
<path d="M790 420 Q850 395 920 420 T1150 390" stroke="#4c8ca3" strokeWidth="9" fill="none" opacity=".45"/>
<g fill="#e1d4ae" opacity=".12" fontSize="55" fontWeight="900" letterSpacing="14"><text x="110" y="150">四川</text><text x="740" y="565">贵州</text><text x="150" y="520">云南</text></g>
{([{x:560,y:310,t:'土城'},{x:535,y:270,t:'太平渡'},{x:490,y:205,t:'二郎滩'},{x:600,y:350,t:'茅台'},{x:750,y:370,t:'遵义'},{x:780,y:455,t:'乌江'},{x:270,y:350,t:'扎西'}]).map(c=><g key={c.t}><circle cx={c.x} cy={c.y} r="4" fill="#e6d9bb"/><text x={c.x+12} y={c.y-10} className="city">{c.t}</text></g>)}
<text x="420" y="120" transform="rotate(49 420 120)" fill="#a4ced5" fontSize="17" letterSpacing="5">赤水河</text>
<path d={d} fill="none" stroke="#f0c17e" strokeWidth="13" opacity=".22" filter="url(#glow)"/>
<path key={scene.name} d={d} className="march" style={{'--reveal':progress} as React.CSSProperties} pathLength="1"/>
{scene.troops.map((p,i)=><g key={'r'+i} transform={`translate(${p[0]} ${p[1]})`} className="counter"><rect x="-28" y="-15" width="56" height="30" rx="3" fill="#aa3d37" stroke="#e6b59a"/><text textAnchor="middle" y="5">{['红一','红三','红五'][i]}</text></g>)}
{scene.enemy.map((p,i)=><g key={'e'+i} transform={`translate(${p[0]} ${p[1]})`} className="counter"><rect x="-28" y="-15" width="56" height="30" rx="3" fill="#3e6e8c" stroke="#9bbdd1"/><text textAnchor="middle" y="5">{['川军','黔军','滇军','追兵'][i]}</text></g>)}
<g transform="translate(75 565)" fontSize="13" fill="#e2dccb"><rect x="-15" y="-32" width="235" height="66" fill="#0e2024" fillOpacity=".82" rx="4"/><rect width="13" height="13" fill="#aa3d37"/><text x="22" y="12">中央红军（示意）</text><rect x="0" y="21" width="13" height="13" fill="#3e6e8c"/><text x="22" y="33">国民党军（示意）</text></g>
<text x="1070" y="595" fill="#c9c5b5" textAnchor="end" fontSize="12" letterSpacing="2">战役态势示意 · 非精确历史地图</text>
</svg>}
function App(){
const [time,setTime]=useState(0),[playing,setPlaying]=useState(false);
useEffect(()=>{if(!playing)return;let prev=performance.now(),raf=0;const tick=(now:number)=>{setTime(t=>Math.min(total,t+(now-prev)/1000));prev=now;raf=requestAnimationFrame(tick)};raf=requestAnimationFrame(tick);return()=>cancelAnimationFrame(raf)},[playing]);
useEffect(()=>{if(time>=total)setPlaying(false)},[time]);
const {i,local}=indexFor(time);const scene=scenes[i];
const startOf=(index:number)=>DURATIONS.slice(0,index).reduce((a,b)=>a+b,0);
const jump=(idx:number)=>{setTime(startOf(Math.max(0,Math.min(5,idx))));setPlaying(false)};
const full=()=>{const el=document.getElementById('film');if(el?.requestFullscreen)el.requestFullscreen()};
const progress=useMemo(()=>Math.min(1,local*1.4),[local]);
return <main><div className="topline"><span className="eyebrow">1935 / THE FOUR CROSSINGS OF CHISHUI</span><span className="quiet"><VolumeX size={14}/> 无音频 · 纯视觉历史叙事</span></div>
<section className="film" id="film"><Map scene={scene} progress={progress}/>
<div className="vignette"/>
<div className="film-top"><div className="logo">四渡赤水 <span>· 战略的主动权</span></div><div className="episode">历史军事沙盘 / {String(i+1).padStart(2,'0')}</div></div>
<div className="datecard" key={'date'+i}><div className="date">{scene.date}</div><div className="scene-name">{scene.name}</div><div className="tag">{scene.tag}</div></div>
<div className="textpanel" key={'text'+i}><div className="rule"/><div className="headline">{scene.headline}</div><div className="thought">{scene.thought}</div><div className="detail">{scene.detail}</div></div>
<div className="filmbottom"><span>毛泽东军事思想视角 · 历史事件由中央红军领导集体指挥</span><span>SCENE {i+1} / {scenes.length}</span></div>
</section>
<div className="controls"><button aria-label="上一幕" onClick={()=>jump(i-1)}><ChevronLeft size={19}/></button><button className="play" onClick={()=>{if(time>=total)setTime(0);setPlaying(v=>!v)}}>{playing?<Pause size={19}/>:<Play size={19}/>} {playing?'暂停':'播放'}</button><button aria-label="下一幕" onClick={()=>jump(i+1)}><ChevronRight size={19}/></button><div className="time">{clock(time)} / {clock(total)}</div><input aria-label="视频进度" type="range" min="0" max={total} step=".1" value={time} onChange={e=>setTime(Number(e.target.value))}/><button title="重新播放" onClick={()=>{setTime(0);setPlaying(false)}}><RotateCcw size={18}/></button><button title="全屏" onClick={full}><Maximize2 size={18}/></button></div>
<div className="chapters">{scenes.map((s,j)=><button key={s.name} className={i===j?'active':''} onClick={()=>jump(j)}><span>{String(j+1).padStart(2,'0')}</span>{s.name}</button>)}</div>
<footer>制作说明：此版本为自动播放的无声沙盘视频原型。地图与部队位置均为示意；不应作为精确历史地图使用。画面中战略思考为现代解说文案，并非毛泽东原话。可在浏览器全屏播放并录制为视频。</footer>
</main>}
export default App;
