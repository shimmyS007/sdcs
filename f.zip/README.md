# 四渡赤水：战略的主动权

无音频、纯视觉的历史军事沙盘动画，采用 React + TypeScript + Vite + SVG 实现。

## 本地运行

```bash
npm install
npm run dev
```

打开终端显示的本地地址。

## 生产构建

```bash
npm run build
npm run preview
```

## 操作

- 点击“播放”，自动播放六幕历史场景。
- 点击章节直接切换一渡、二渡、三渡、四渡和复盘。
- 拖动进度条、暂停、全屏；建议用 16:9 浏览器窗口录制无声视频。
- 可用 OBS 或系统录屏录制，导出 MP4；本项目本身不直接编码 MP4。

## 历史与版权说明

- 本项目为视频演示原型，**地形、河流形状、渡口与兵牌坐标均为示意**，并非准确 GIS 数据或史料地图。
- 各幕战役事件为概述，正式发布前请按权威党史军史资料逐项核对日期、渡口和行动路线。
- “战略思考”均为现代解说文案，**不是毛泽东原话**；四渡赤水由中央红军领导集体指挥。
- 无外部图片、音乐或视频素材依赖；图形由 SVG 绘制。

## GitHub 上传

在 GitHub 新建空仓库 `chishui-film`，不要勾选自动生成 README，然后：

```bash
git init
git add .
git commit -m "Initial silent Chishui campaign film demo"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/chishui-film.git
git push -u origin main
```
